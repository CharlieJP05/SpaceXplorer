//
// Created by charl on 08/05/2025.
//

#ifndef FILES_H
#define FILES_H

void add(char *str,char name[10],char diff[10],int score);
void make(char *str);
int parse(char *str,char diffs[100][10][10]);


#endif //FILES_H
